const state = {
    tabbarName:'home'
}
const mutations = {
    SETTABBER(state,tabName){
        state.tabbarName = tabName
    }
}
const actions = {

  
}

export default {
  namespaced:true,
  state,
  mutations,
  actions,
}